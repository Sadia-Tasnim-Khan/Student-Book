package com.example.dell.studentbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    public static String User_Name = "username";
     EditText userName,password;
     Button signin, signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_activity);
        userName =(EditText)findViewById(R.id.enterNameET);
        password =(EditText)findViewById(R.id.enterPasswordET);
        signin =(Button) findViewById(R.id.SignINBtn);
        signup =(Button)findViewById(R.id.SignUpBtn);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usename = userName.getText().toString();

                Intent i = new Intent(getApplicationContext(),OptionBar_activity.class);
                i.putExtra(User_Name,usename);
                startActivity(i);
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Signup_activity.class);
                startActivity(i);
            }
        });
    }
}
