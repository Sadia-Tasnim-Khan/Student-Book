package com.example.dell.studentbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Signup_activity extends AppCompatActivity {


    public static String User_Name = "username";
    Button signup;
    EditText uname, pass1, pass2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_activity);


        uname = (EditText)findViewById(R.id.enterNameET);
        pass1 = (EditText)findViewById(R.id.enterPasswordET);
        pass2 = (EditText)findViewById(R.id.enterReCheakPasswordET);
        signup = (Button)findViewById(R.id.SignupBtn);


        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String unameSU = uname.getText().toString();
                String pass1SU = pass1.getText().toString();
                String pass2SU = pass2.getText().toString();

                if(pass1SU.equals(pass2SU) && !pass1SU.isEmpty())
                {
                    //Log.d("SIGN UP:","Success");
                    Toast pass = Toast.makeText(getApplicationContext(),"Sign Up Success",Toast.LENGTH_SHORT);
                    pass.show();
                    Intent i = new Intent(getApplicationContext(),OptionBar_activity.class);
                    i.putExtra(User_Name,unameSU);
                    startActivity(i);
                }

                else if(pass1SU.isEmpty())
                {
                    //Log.d("SIGN UP:","Success not");
                    Toast pass1 = Toast.makeText(getApplicationContext(),"Fill all the info",Toast.LENGTH_SHORT);
                    pass1.show();
                }

                else
                {
                    //Log.d("SIGN UP:","Success not");
                    Toast pass1 = Toast.makeText(getApplicationContext(),"Passwords Don't Match",Toast.LENGTH_SHORT);
                    pass1.show();
                }
            }
        });

    }
}
