package com.example.dell.studentbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class OptionBar_activity extends AppCompatActivity {


    Button CgCalcu, SBasicInfo,Routine;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option_bar_activity);

        String username = getIntent().getStringExtra(MainActivity.User_Name);
        TextView t = (TextView)findViewById(R.id.welcomeName);
        t.setText(username);

        String username2 = getIntent().getStringExtra(Signup_activity.User_Name);
        TextView t2 = (TextView)findViewById(R.id.welcomeName);
        t2.setText(username2);

        CgCalcu = (Button)findViewById(R.id.CGcalcuBtnBtn);
        SBasicInfo = (Button)findViewById(R.id.studentInfoBtn);
        Routine = (Button)findViewById(R.id.routineBtnBtn);


        CgCalcu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),CgpaCalculation_1_activity.class);
                startActivity(i);
            }
        });

        SBasicInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),SBasicInfo_activity.class);
                startActivity(i);
            }
        });
        Routine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Routine_activity.class);
                startActivity(i);
            }
        });


    }
}
