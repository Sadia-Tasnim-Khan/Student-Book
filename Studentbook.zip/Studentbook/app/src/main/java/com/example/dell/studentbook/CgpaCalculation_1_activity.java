package com.example.dell.studentbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CgpaCalculation_1_activity extends AppCompatActivity {

    Button Next,Calculate ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cgpa_calculation_1_activity);

        Next = (Button)findViewById(R.id.NextBtn);
        Calculate = (Button)findViewById(R.id.CalculateBtn);

        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),CgpaCalculation_1_activity.class);
                startActivity(i);
            }
        });

        Calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),CgpaCalculation_2_activity.class);
                startActivity(i);
            }
        });




    }
}
